Citadel-Rx, revised manuscript (IEEE TWC).
Compile: pdflatex main && pdflatex main (or upload this folder to Overleaf).
numbers.tex (every result number) and tables/ are generated from the run records by `make paper`
in https://github.com/abraheemrashid99-sys/Citradel-Rx; edit the text, not those files.
